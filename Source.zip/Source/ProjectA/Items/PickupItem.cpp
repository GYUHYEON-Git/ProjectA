﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "Items/PickupItem.h"

#include "Define.h"
#include "Equipments/Equipment.h"
#include "Characters/PlayerCharacter.h"
#include "Components/SphereComponent.h"
#include "Components/WidgetComponent.h"
#include "UI/TextWidget.h"

APickupItem::APickupItem()
{
	PrimaryActorTick.bCanEverTick = true;
	Mesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("PickupItemMesh"));
	SetRootComponent(Mesh);

	Mesh->SetCollisionObjectType(COLLISION_OBJECT_INTERACTION);
	Mesh->SetCollisionResponseToChannel(ECC_Camera, ECR_Ignore);
	Mesh->SetCollisionResponseToChannel(ECC_Pawn, ECR_Overlap);
}

void APickupItem::BeginPlay()
{
	Super::BeginPlay();
}

void APickupItem::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void APickupItem::OnConstruction(const FTransform& Transform) {
	Super::OnConstruction(Transform);
	if (EquipmentClass) {
		if (AEquipment* CDO = EquipmentClass->GetDefaultObject<AEquipment>()) {
			Mesh->SetStaticMesh(CDO->MeshAsset);
			Mesh->SetSimulatePhysics(true);
		}
	}
}

// Interact 인터페이스를 상속받아 Interact 함수 구현
void APickupItem::Interact(AActor* InteractorActor) {
	FActorSpawnParameters SpawnParams;
	SpawnParams.Owner = InteractorActor;
	// 클래스에 저장되어 있는 AEquipment 액터를 생성 후 장비 장착 및 기존에 레벨에 배치된 AEquipment 액터 제거
	AEquipment* SpawnItem = GetWorld()->SpawnActor<AEquipment>(EquipmentClass, GetActorTransform(), SpawnParams);
	if (SpawnItem) {
		SpawnItem->EquipItem();
		Destroy();
	}
}

