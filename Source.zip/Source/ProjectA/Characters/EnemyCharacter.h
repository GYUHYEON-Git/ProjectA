// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Interfaces/Targeting.h"
#include "Interfaces/CombatInterface.h"
#include "GameFramework/Character.h"
#include "EnemyCharacter.generated.h"

class UWidgetComponent;
class USphereComponent;
class UAttributeComponent;
class UStateComponent;
class UCombatComponent;
class URotationComponent;
class UMusicComponent;
class ATargetPoint;
class AWeapon;

UCLASS()
class PROJECTA_API AEnemyCharacter : public ACharacter, public ITargeting, public ICombatInterface
{
	GENERATED_BODY()

protected:
	UPROPERTY(VisibleAnywhere, Category = "Components")
	TObjectPtr<USphereComponent> TargetingSphereComponent;

	UPROPERTY(VisibleAnywhere, Category = "Components")
	TObjectPtr<UAttributeComponent> AttributeComponent;

	UPROPERTY(VisibleAnywhere, Category = "Components")
	TObjectPtr<UStateComponent> StateComponent;

	UPROPERTY(VisibleAnywhere, Category = "Components")
	TObjectPtr<UCombatComponent> CombatComponent;

	UPROPERTY(VisibleAnywhere, Category = "Components")
	TObjectPtr<URotationComponent> RotationComponent;

	UPROPERTY(VisibleAnywhere, Category = "Components")
	TObjectPtr<UMusicComponent> MusicComponent;

	UPROPERTY(VisibleAnywhere, Category = "Components")
	TObjectPtr<UWidgetComponent> LockOnWidgetComponent;

	UPROPERTY(VisibleAnywhere, Category = "Components")
	TObjectPtr<UWidgetComponent> HealthBarWidgetComponent;

protected:
	UPROPERTY(EditAnywhere, Category = "Effect")
	TObjectPtr<USoundBase> ImpactSound;

	UPROPERTY(EditAnywhere, Category = "Effect")
	TObjectPtr<UParticleSystem> ImpactParticle;

protected:
	UPROPERTY(EditAnywhere, Category = "AI | Patrol")
	TArray<TObjectPtr<ATargetPoint>> PatrolPoints;

	UPROPERTY(VisibleAnywhere, Category = "AI | Patrol")
	int32 PatrolIndex = 0;

protected:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSubclassOf<AWeapon> DefaultWeaponClass;

protected:
	FTimerHandle ParriedDelayTimerHandle;
	FTimerHandle StunnedDelayTimerHandle;

	UPROPERTY(EditAnywhere)
	int StunnedRate = 0;

public:
	AEnemyCharacter();

protected:
	virtual void BeginPlay() override;

public:	
	virtual void Tick(float DeltaTime) override;
	virtual float TakeDamage(float Damage, const FDamageEvent& DamageEvent, AController* EventInstigator, AActor* DamageCauser) override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;

protected:
	virtual void OnDeath();
	void OnAttributeChanged(EAttributeType AttributeType, float InValue);
	void SetupHealthBar();

protected:
	void ImpactEffect(const FVector& Location);
	void HitReaction(const AActor* Attacker);

public:
	// Targeting
	virtual void OnTargeted(bool bTargeted) override;
	virtual bool CanBeTargeted() override;

	// ICombatInterface.
	virtual void ActivateWeaponCollision(EWeaponCollisionType WeaponCollisionType) override;
	virtual void DeactivateWeaponCollision(EWeaponCollisionType WeaponCollisionType) override;
	virtual void PerformAttack(FGameplayTag& AttackTypeTag, FOnMontageEnded& MontageEndedDelegate) override;
	virtual void Parried() override;

	void ToggleHealthBarVisibility(bool bVisibility);
	void SetCombatUIAndAudioActive(bool bIsActive);

public:
	void StartMusic();
	void StopMusic();

public:
	FORCEINLINE ATargetPoint* GetPatrolPoint(){
		return PatrolPoints.Num() >= (PatrolIndex + 1) ? PatrolPoints[PatrolIndex] : nullptr;
	}
	FORCEINLINE void IncrementPatrolIndex() {
		PatrolIndex = (PatrolIndex + 1) % PatrolPoints.Num();
	}

};